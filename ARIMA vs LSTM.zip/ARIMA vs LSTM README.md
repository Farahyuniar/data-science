# Perbandingan Model LSTM dan ARIMA untuk Prediksi Pengelolaan Sampah Tahunan

# 🧠 Deskripsi Proyek

Proyek ini membandingkan kinerja model Long Short-Term Memory (LSTM) dan ARIMA (Autoregressive Integrated Moving Average) dalam memprediksi volume sampah dan hasil pengelolaannya setiap bulan. Kedua notebook (`Model_LSTM.ipynb` dan `Model_ARIMA.ipynb`) menerapkan model-model ini untuk menentukan model yang lebih akurat dan efisien.

## 🎯 Tujuan Proyek

Tujuan utama proyek ini adalah:

* **Implementasi Model LSTM dan ARIMA:** Mengimplementasikan model LSTM (menggunakan TensorFlow/Keras) dan model ARIMA (menggunakan `statsmodels` dan `pmdarima`) untuk prediksi deret waktu.
* **Prediksi Volume Sampah:** Memprediksi volume bulanan untuk berbagai jenis sampah dan hasil pengelolaannya.
* **Perbandingan Akurasi:** Membandingkan akurasi prediksi antara model LSTM dan ARIMA untuk setiap jenis sampah dan hasil pengelolaan.
* **Evaluasi Metrik Kinerja:** Mengevaluasi kinerja model menggunakan Mean Absolute Error (MAE) dan Root Mean Squared Error (RMSE) sebagai metrik utama.
* **Identifikasi Model Terbaik:** Menentukan apakah LSTM atau ARIMA lebih cocok untuk memprediksi pola deret waktu dalam dataset pengelolaan sampah ini.
* **Analisis Model:** Mengidentifikasi kekuatan dan kelemahan masing-masing model dalam konteks prediksi pengelolaan sampah.

## 📁 Dataset

Dataset yang digunakan adalah data bulanan pengelolaan sampah.

**PENTING:** Detail rinci mengenai dataset (misalnya, sumber, frekuensi, deskripsi kolom) bersifat sensitif dan memerlukan izin lebih lanjut dari pemilik data. Jika Anda tertarik untuk mendapatkan akses ke detail dataset, silakan hubungi penulis proyek melalui informasi kontak yang diberikan di bawah.

* **Tahun:** Tahun (misalnya, 2020, 2021, 2022, 2023, 2024).
* **Bulan:** Bulan (misalnya, January, February, ..., December).
* **Sampah Daun:** Volume sampah daun yang dikumpulkan (unit volume).
* **Sampah Sayuran:** Volume sampah sayuran yang dikumpulkan (unit volume).
* **Sampah Anorganik:** Volume sampah anorganik yang dikumpulkan (unit volume).
* **Daun Terolah:** Volume daun yang diolah (unit volume).
* **Sampah Fermentasi:** Volume sampah yang difermentasi (unit volume).
* **Kompos Jadi:** Volume kompos yang dihasilkan (unit volume).

### Notebook 1: Model_LSTM.ipynb

Notebook ini mengimplementasikan model LSTM untuk memprediksi volume sampah dan hasil pengelolaannya.

**Alur Kerja Utama:**

1.  **Import Libraries:** Mengimpor library Python yang diperlukan (Pandas, NumPy, Matplotlib, Seaborn, TensorFlow/Keras, Scikit-learn).
2.  **Load Data:** Memuat dataset pengelolaan sampah bulanan.
3.  **Data Preprocessing:**
    * (Mungkin) Melakukan eksplorasi data awal (EDA) untuk memahami pola dan tren.
    * (Mungkin) Menangani nilai yang hilang atau outlier.
    * Melakukan penskalaan data menggunakan `MinMaxScaler`.
    * Membagi data menjadi set pelatihan dan pengujian.
    * Mempersiapkan data deret waktu untuk input LSTM (membuat urutan atau jendela data).
4.  **Model Building:**
    * Membangun arsitektur model LSTM (dengan lapisan LSTM dan Dense).
    * Menentukan hyperparameter model LSTM (misalnya, jumlah lapisan, jumlah neuron).
    * Mengkompilasi model dengan *optimizer* dan *loss function* yang sesuai.
5.  **Model Training:** Melatih model LSTM pada set pelatihan.
6.  **Model Evaluation:**
    * Membuat prediksi pada set pengujian.
    * Menghitung MAE dan RMSE untuk mengukur akurasi prediksi.
    * Memvisualisasikan hasil prediksi dibandingkan dengan data aktual.
7.  **Conclusion:** Meringkas kinerja model LSTM dan memberikan pengamatan tentang prediksi.

### Notebook 2: Model_ARIMA.ipynb

Notebook ini mengimplementasikan model ARIMA untuk memprediksi volume sampah dan hasil pengelolaannya.

**Alur Kerja Utama:**

1.  **Import Libraries:** Mengimpor library Python yang diperlukan (Pandas, NumPy, Matplotlib, `statsmodels`, `pmdarima`).
2.  **Load Data:** Memuat dataset pengelolaan sampah bulanan.
3.  **Data Preprocessing:**
    * (Mungkin) Melakukan eksplorasi data awal (EDA).
    * (Mungkin) Menangani nilai yang hilang atau outlier.
    * Memeriksa stasioneritas data menggunakan *Augmented Dickey-Fuller test* (`adfuller`).
    * Melakukan *differencing* (jika perlu) untuk membuat data stasioner.
    * Membagi data menjadi set pelatihan dan pengujian.
4.  **Model Building:**
    * Menentukan parameter ARIMA (p, d, q) menggunakan `pmdarima.auto_arima` (atau metode lain untuk pemilihan parameter).
    * Membangun model ARIMA menggunakan `statsmodels.tsa.arima.model.ARIMA`.
5.  **Model Training:** Melatih model ARIMA pada set pelatihan.
6.  **Model Evaluation:**
    * Membuat prediksi pada set pengujian.
    * Menghitung MAE dan RMSE untuk mengukur akurasi prediksi.
    * Memvisualisasikan hasil prediksi dibandingkan dengan data aktual.
7.  **Conclusion:** Meringkas kinerja model ARIMA dan memberikan pengamatan tentang prediksi.

**Perbandingan dan Kesimpulan Umum**

Setelah menjalankan kedua notebook, proyek ini akan menghasilkan kesimpulan tentang:

* Model mana (LSTM atau ARIMA) yang memberikan prediksi lebih akurat untuk setiap jenis sampah dan hasil pengelolaan.
* Kekuatan dan kelemahan model LSTM dan ARIMA dalam memprediksi pola musiman dan tren jangka panjang dalam data pengelolaan sampah.
* Pertimbangan praktis dalam memilih model yang tepat untuk aplikasi pengelolaan sampah (misalnya, kompleksitas implementasi, kebutuhan komputasi).

## Cara Menjalankan

Untuk menjalankan notebook ini, Anda memerlukan:

* Python 3.x
* Library Python yang tercantum di bagian "Import Libraries" di setiap notebook. Instal menggunakan `pip install <nama_library>`.
    * Contoh: `pip install pandas numpy matplotlib seaborn scikit-learn tensorflow pmdarima statsmodels`
* Jupyter Notebook atau JupyterLab

Langkah-langkah:

1.  Pastikan Python dan semua library yang diperlukan sudah terinstal.
2.  Unduh atau *clone* repositori ini.
3.  Buka dan jalankan semua sel secara berurutan di notebook `Model_LSTM.ipynb`.
4.  Buka dan jalankan semua sel secara berurutan di notebook `Model_ARIMA.ipynb`.
5.  Bandingkan hasil dari kedua notebook (MAE, RMSE, visualisasi prediksi) untuk menarik kesimpulan.

## 👩‍💻 Author

Jika Anda membutuhkan informasi lebih lanjut mengenai dataset yang digunakan dalam proyek ini, silakan hubungi penulis proyek di:

**Farah Yuniar Alin Raihatuzzahra**  
NIM: A11.2021.13585  
Universitas Dian Nuswantoro  
📧 Email: [farahyuniarali@gmail.com]  
📎 GitHub: [https://github.com/Farahyuniar](https://github.com/Farahyuniar)


## 📜 Lisensi

Proyek ini dibuat untuk tujuan pembelajaran dan edukasi. Dataset berasal dari sumber non-publik dan digunakan secara non-komersial.

## Catatan Tambahan

* Penting untuk menganalisis pola musiman dan tren dalam data pengelolaan sampah untuk memilih model yang tepat.
* Pemilihan hyperparameter dan parameter model (p, d, q) sangat mempengaruhi kinerja.
* Visualisasi prediksi membantu dalam memahami kemampuan model untuk menangkap pola data.
* Pertimbangkan implikasi praktis (misalnya, kebutuhan komputasi) dalam memilih model untuk sistem pengelolaan sampah.