# Prediksi Risiko Gagal Jantung Berdasarkan Data Klinis

# 🧠 Fetal Health Classification Analysis

Proyek ini bertujuan untuk mengembangkan model machine learning untuk memprediksi risiko gagal jantung berdasarkan data klinis pasien. Gagal jantung adalah kondisi serius yang memerlukan diagnosis dan penanganan dini. Dengan memanfaatkan data klinis, model prediksi dapat membantu tenaga medis dalam mengidentifikasi pasien yang berisiko tinggi dan memberikan intervensi yang tepat waktu.

## 📁 Deskripsi Proyek

Dataset yang digunakan adalah "Heart failure clinical records dataset" (atau sesuaikan dengan nama file yang tepat). Dataset ini berisi informasi tentang berbagai faktor kesehatan yang terkait dengan gagal jantung. Setiap baris dalam dataset mewakili satu pasien, dan setiap kolom mewakili variabel klinis.

**Variabel Dataset**

* **age:** 
* **anaemia:** 
* **creatinine\_phosphokinase:** 
* **diabetes:** 
* **ejection\_fraction:** 
* **high\_blood\_pressure:** 
* **platelets:** 
* **serum\_creatinine:** 
* **serum\_sodium:** 
* **sex:** 
* **smoking:** 
* **time:** 
* **DEATH\_EVENT:**
* **Target Variabel**.


**(Catatan:** Sesuaikan daftar variabel di atas dengan kolom sebenarnya di dataset Anda.)

## 📂 Struktur File

```
📦 heart_failure_clinical_record_dataset
 ┣ 📄 heart_failure...README.md
 ┣ 📄 heart_failure_clinical_record_dataset.ipynb
 ┗ 📁 heart_failure_clinical_record_dataset.csv
```

## Alur Kerja Proyek

Notebook ini mengikuti alur kerja proyek data science yang terstruktur:

1.  **Import Libraries:**
    * Mengimpor library Python penting untuk manipulasi data (`Pandas`, `NumPy`), visualisasi (`Matplotlib`, `Seaborn`), dan machine learning (`Scikit-learn`).
2.  **Load Data:**
    * Membaca dataset dari file CSV (atau format lain) menggunakan Pandas.
    * Menampilkan beberapa baris pertama dataset untuk pemeriksaan awal.
    * Memeriksa ukuran dataset (jumlah baris dan kolom).
    * Melihat informasi tipe data setiap kolom.
3.  **Exploratory Data Analysis (EDA):**
    * **Statistik Deskriptif:** Menghitung statistik seperti mean, median, standar deviasi, dan kuartil untuk kolom numerik.
    * **Distribusi Variabel:** Memvisualisasikan distribusi variabel numerik menggunakan histogram dan boxplot.
    * **Korelasi:** Menghitung dan memvisualisasikan korelasi antar variabel menggunakan heatmap.
    * **Analisis Variabel Kategorikal:** Menghitung frekuensi kemunculan setiap kategori dalam variabel kategorikal menggunakan count plots.
    * **Analisis Target Variabel:** Memahami distribusi kelas dalam variabel target (`DEATH_EVENT`).
    * **Hubungan Variabel:** Memvisualisasikan hubungan antara variabel independen dan variabel target menggunakan boxplot, barplot, atau scatter plot.
4.  **Data Preprocessing:**
    * **Missing Value Handling:**
        * Memeriksa keberadaan nilai yang hilang di setiap kolom.
        * Menangani nilai yang hilang menggunakan metode yang sesuai (misalnya, imputasi dengan mean, median, atau modus).
    * **Outlier Detection and Handling (Opsional):**
        * Mengidentifikasi outlier dalam kolom numerik (misalnya, menggunakan metode IQR atau z-score).
        * Menangani outlier (misalnya, dengan menghapusnya atau mengubahnya).
    * **Encoding Variabel Kategorikal:**
        * Mengubah variabel kategorikal menjadi representasi numerik yang sesuai untuk model machine learning (misalnya, menggunakan one-hot encoding).
    * **Feature Scaling:**
        * Menskalakan fitur numerik ke rentang yang sama untuk mencegah variabel dengan skala besar mendominasi model (misalnya, menggunakan StandardScaler atau MinMaxScaler).
5.  **Model Building and Training:**
    * **Data Splitting:** Membagi dataset menjadi set pelatihan dan set pengujian untuk mengevaluasi kinerja model pada data yang belum pernah dilihat sebelumnya.
    * **Model Selection:**
        * Memilih algoritma klasifikasi yang relevan (misalnya, Logistic Regression, Decision Tree, Random Forest, Support Vector Machine, Gradient Boosting).
        * (Mungkin) Melatih beberapa model dan membandingkan kinerja awal mereka.
    * **Hyperparameter Tuning (Opsional):**
        * Mengoptimalkan hyperparameter model yang dipilih menggunakan teknik seperti GridSearchCV atau RandomizedSearchCV.
    * **Model Training:** Melatih model yang dipilih (dengan hyperparameter terbaik, jika di-tuning) pada set pelatihan.
6.  **Model Evaluation:**
    * **Prediction:** Membuat prediksi pada set pengujian menggunakan model yang telah dilatih.
    * **Evaluation Metrics:**
        * Menghitung metrik evaluasi yang relevan untuk klasifikasi biner, seperti:
            * **Accuracy:** Proporsi prediksi yang benar.
            * **Precision:** Proporsi prediksi positif yang benar.
            * **Recall:** Proporsi instance positif yang sebenarnya berhasil diprediksi.
            * **F1-score:** Rata-rata harmonik dari precision dan recall.
            * **AUC-ROC:** Area Under the Receiver Operating Characteristic curve (mengukur kemampuan model membedakan antara kelas).
        * Menampilkan **Confusion Matrix** untuk visualisasi kinerja klasifikasi.
        * Menghasilkan **Classification Report** untuk ringkasan metrik per kelas.
    * **Feature Importance (Opsional):**
        * Jika model yang digunakan mendukungnya, menganalisis feature importance untuk memahami variabel mana yang paling berpengaruh dalam prediksi.
7.  **Conclusion:**
    * Meringkas temuan utama dari analisis data dan kinerja model.
    * Mendiskusikan implikasi praktis dari model dan potensi penggunaannya.
    * (Mungkin) Menyarankan arah untuk penelitian atau pengembangan lebih lanjut.

## Cara Menjalankan

Untuk menjalankan notebook ini, Anda memerlukan:

* Python 3.x
* Library Python yang tercantum di bagian "Import Libraries" (Anda dapat menginstalnya menggunakan `pip install <nama\_library>`). Contoh: `pip install pandas numpy matplotlib seaborn scikit-learn`
* Jupyter Notebook atau JupyterLab (Anda dapat menginstalnya menggunakan `pip install jupyterlab`)

Langkah-langkah:

1.  Pastikan Anda telah menginstal Python dan semua library yang diperlukan.
2.  Unduh atau clone repositori ini.
3.  Buka notebook `heart_failure_clinical_records_dataset.ipynb` menggunakan Jupyter Notebook atau JupyterLab.
4.  Jalankan setiap sel dalam notebook secara berurutan untuk mengeksekusi kode dan menghasilkan output.

## Catatan Tambahan

* Penyesuaian lebih lanjut pada alur kerja atau kode mungkin diperlukan tergantung pada karakteristik spesifik dataset dan tujuan proyek.
* Interpretasi yang cermat dari hasil dan pemahaman domain yang baik sangat penting dalam proyek analisis data medis.

## 👩‍💻 Author

**Farah Yuniar Alin Raihatuzzahra**  
NIM: A11.2021.13585  
Universitas Dian Nuswantoro  
📧 Email: [farahyuniarali@gmail.com]  
📎 GitHub: [https://github.com/Farahyuniar](https://github.com/Farahyuniar)

---

## 📜 Lisensi

Proyek ini dibuat untuk tujuan pembelajaran dan edukasi. Dataset berasal dari sumber publik dan digunakan secara non-komersial.
