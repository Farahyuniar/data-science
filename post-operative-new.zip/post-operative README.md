# Analisis dan Prediksi Kondisi Pasien Pasca Operasi

# 🧠 post-operative

Proyek ini bertujuan untuk menganalisis data pasien pasca operasi dan membangun model machine learning untuk memprediksi kondisi pasien setelah operasi. Tujuan utama adalah untuk mengidentifikasi faktor-faktor yang mempengaruhi hasil pemulihan dan membantu dalam pengambilan keputusan klinis.

## 📁 Dataset

Dataset yang digunakan adalah "Post-Operative Recovery Data". Dataset ini berisi informasi tentang berbagai karakteristik pasien sebelum, selama, dan setelah operasi.

## 📂 Struktur File

```
📦 post-operative
 ┣ 📄 post-operative README.md
 ┣ 📄 post-operative.ipynb
 ┗ 📁 post-operative-new.data
```

 ## 🎯 Variabel Dataset

Berdasarkan data yang Anda berikan, berikut adalah deskripsi variabel:

* **0 (L-CORE):** Suhu inti tubuh pasien (kategori: low, mid, high).
* **1 (L-SURF):** Suhu permukaan tubuh pasien (kategori: low, mid, high).
* **2 (L-O2):** Saturasi oksigen (kategori: excellent, good).
* **3 (L-BP):** Tekanan darah (kategori: low, mid, high).
* **4 (SURF-STBL):** Stabilitas permukaan (kategori: stable, unstable).
* **5 (CORE-STBL):** Stabilitas inti (kategori: stable, unstable).
* **6 (BP-STBL):** Stabilitas tekanan darah (kategori: stable, unstable, mod-stable).
* **COMFORT:** Tingkat kenyamanan pasien (numerik, skala 0-20).
* **ADM-DECS:** Keputusan penerimaan pasien ke ruang perawatan intensif (ICU) atau tidak (kategori: A = dipulangkan, S = tetap tinggal, I = dipindahkan).

## 🧩 Alur Kerja Proyek

Notebook ini mengikuti alur kerja data science yang terstruktur:

1.  **Mengumpulkan Data:**
    * Membaca dataset dari file CSV menggunakan Pandas.
    * Menampilkan beberapa baris pertama dataset untuk pemeriksaan awal.
    * Mencetak informasi tentang jumlah baris, kolom, dan tipe data.

2.  **Menelaah Data:**
    * Menganalisis statistik deskriptif dari kolom numerik (COMFORT).
    * Menganalisis distribusi nilai dalam kolom kategorikal (semua kolom lainnya).

3.  **Memvalidasi Data:**
    * Memeriksa apakah ada nilai-nilai yang tidak konsisten atau tidak masuk akal (misalnya, nilai di luar rentang yang valid).
    * Memeriksa keberadaan dan pola nilai yang hilang.

4.  **Menentukan Object Data:**
    * Secara eksplisit mengidentifikasi kolom-kolom kategorikal.

5.  **Membersihkan Data:**
    * Menangani nilai-nilai yang hilang (misalnya, mengganti dengan nilai yang paling sering muncul atau metode imputasi lainnya).
    * (Mungkin) Memperbaiki inkonsistensi dalam data kategorikal.

6.  **Mengkonstruksi Data (Opsional):**
    * (Mungkin) Membuat fitur baru dari fitur yang ada (ini tidak terlihat jelas dalam notebook yang diberikan, tetapi bisa ditambahkan).

7.  **Menentukan Label Data:**
    * Menetapkan kolom `ADM-DECS` sebagai variabel target (yang akan diprediksi).

8.  **Membangun Model:**
    * Membagi dataset menjadi set pelatihan dan set pengujian.
    * Melatih model klasifikasi (Random Forest, atau model lain yang dipilih dalam notebook) pada set pelatihan.
    * (Mungkin) Melakukan *hyperparameter tuning* menggunakan `GridSearchCV` atau metode lain.

9.  **Mengevaluasi Hasil Pemodelan:**
    * Membuat prediksi pada set pengujian.
    * Menghitung metrik evaluasi seperti akurasi, precision, recall, dan F1-score.
    * Menampilkan *classification report* dan *confusion matrix*.
    * Memvisualisasikan hasil evaluasi (misalnya, menggunakan grafik batang untuk perbandingan metrik).

## 📌 Cara Menjalankan

Untuk menjalankan notebook ini, Anda memerlukan:

* Python 3.x
* Library Python yang tercantum di bagian "Mengimpor Library yang Diperlukan" (Anda dapat menginstalnya menggunakan `pip`). Contoh: `pip install pandas numpy matplotlib seaborn scikit-learn`
* Jupyter Notebook atau JupyterLab

Langkah-langkah:

1.  Pastikan Anda telah menginstal Python dan semua library yang diperlukan.
2.  Unduh atau clone repositori ini.
3.  Buka notebook `post-operative.ipynb` menggunakan Jupyter Notebook atau JupyterLab.
4.  Jalankan setiap sel dalam notebook secara berurutan.

## Catatan Tambahan

* Dataset ini memiliki beberapa nilai yang hilang (ditandai dengan "?", atau kosong dalam contoh yang diberikan). Penanganan nilai yang hilang sangat penting.
* Sebagian besar fitur bersifat kategorikal, sehingga *encoding* yang tepat (misalnya, *one-hot encoding*) diperlukan sebelum melatih model.
* Interpretasi hasil model harus dilakukan dengan hati-hati dan dengan mempertimbangkan implikasi klinis.
* Eksplorasi lebih lanjut dengan model lain, teknik validasi silang, dan *feature engineering* dapat meningkatkan kinerja dan pemahaman.

## 👩‍💻 Author

**Farah Yuniar Alin Raihatuzzahra**  
NIM: A11.2021.13585  
Universitas Dian Nuswantoro  
📧 Email: [farahyuniarali@gmail.com]  
📎 GitHub: [https://github.com/Farahyuniar](https://github.com/Farahyuniar)

---

## 📜 Lisensi

Proyek ini dibuat untuk tujuan pembelajaran dan edukasi. Dataset berasal dari sumber publik dan digunakan secara non-komersial.