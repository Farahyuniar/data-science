
# 📊 Analisis Dataset AIDS (AIDS_DIRTY.ipynb)

Proyek ini merupakan eksplorasi dan pembersihan data terkait penderita AIDS berdasarkan data yang masih "kotor" (belum diproses). Tujuannya adalah untuk memahami pola distribusi kasus AIDS dan mempersiapkan data untuk analisis lebih lanjut.

---

## 📁 Deskripsi Proyek

- **Nama Notebook**: `AIDS_DIRTY.ipynb`
- **Bahasa**: Python
- **Tools & Library**: Pandas, Matplotlib, Seaborn, NumPy

---

## 🎯 Tujuan

- Membersihkan dataset AIDS yang masih mengandung missing values, duplikasi, dan ketidakkonsistenan.
- Melakukan analisis deskriptif untuk memahami tren dan pola dalam data.
- Menyajikan visualisasi awal sebagai dasar analisis lebih lanjut.

---

## 📌 Tahapan Analisis

1. **Import Dataset**
2. **Exploratory Data Analysis (EDA)**
3. **Deteksi & Penanganan Missing Values**
4. **Normalisasi Data**
5. **Visualisasi Awal**

---

## 🧩 Dataset

Dataset dalam proyek ini bersifat mentah ("dirty") dan memerlukan preprocessing sebelum digunakan untuk analisis lanjutan. Kolom utama mencakup:

- Usia
- Jenis Kelamin
- Provinsi
- Tahun Diagnosa
- Status Infeksi

---

## 📊 Hasil Sementara

- Terdapat data duplikat dan missing values yang harus ditangani
- Distribusi penderita AIDS per provinsi tidak merata
- Ada korelasi antara usia dan tingkat infeksi

---

## 📂 Struktur File

```
📦 AIDS Analysis
 ┣ 📄 README.md
 ┣ 📄 AIDS_DIRTY.ipynb
 ┗ 📁 AIDS_DIRTY.csv
```

---

## 👩‍💻 Author

**Farah Yuniar Alin Raihatuzzahra**  
NIM: A11.2021.13585  
Universitas Dian Nuswantoro  
📧 Email: [farahyuniarali@gmail.com]  
📎 GitHub: [https://github.com/Farahyuniar](https://github.com/Farahyuniar)

---

## 📝 Lisensi

Proyek ini menggunakan lisensi bebas pakai untuk tujuan pembelajaran dan non-komersial.
